?package(source):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="source" command="/usr/bin/source"
