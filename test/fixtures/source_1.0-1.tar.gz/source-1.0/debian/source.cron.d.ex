#
# Regular cron jobs for the source package
#
0 4	* * *	root	[ -x /usr/bin/source_maintenance ] && /usr/bin/source_maintenance
