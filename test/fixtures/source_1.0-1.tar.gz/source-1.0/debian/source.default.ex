# Defaults for source initscript
# sourced by /etc/init.d/source
# installed at /etc/default/source by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
